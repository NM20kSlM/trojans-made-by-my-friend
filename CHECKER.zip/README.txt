Hello!
This is ransomware made by A-177 (aka THE GOD)
This is written on BATCH script
Don't run this on actual hardware